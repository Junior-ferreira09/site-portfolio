# 📸 Bruna Barbosa — Site Portfólio Fotografia

Site profissional para a fotógrafa **Bruna Barbosa**, de Nova Mutum - MT.

> ⚡ **100% estático** — Basta abrir o `index.html` no navegador. Sem instalação, sem servidor, sem complicação!

---

## 🚀 Como Usar (Passo a Passo para Iniciantes)

### 1. Abrir o site
- Dê **dois cliques** no arquivo `index.html`
- Ele vai abrir no seu navegador (Chrome, Firefox, Edge...)
- Pronto! O site está funcionando ✅

### 2. Publicar na internet (GRÁTIS)
Recomendo o **Netlify** — é grátis e fácil:

1. Acesse [app.netlify.com](https://app.netlify.com)
2. Crie uma conta (pode usar Google)
3. Arraste a **pasta inteira do projeto** para a área de upload
4. Pronto! Você recebe um link tipo `https://seu-site.netlify.app`
5. (Opcional) Configure um domínio personalizado tipo `brunabarbosa.photo`

---

## 🎬 Como Trocar o Vídeo do Hero

O vídeo do hero é o vídeo de fundo que aparece na tela inicial do site.

### Passo 1: Prepare seu vídeo
- **Formato:** MP4 (H.264)
- **Tamanho ideal:** máximo **10MB** (para carregar rápido)
- **Resolução:** 1920x1080 (Full HD)
- **Duração:** 10-30 segundos (vai rodar em loop)
- **Dica:** Use [handbrake.fr](https://handbrake.fr) para comprimir o vídeo

### Passo 2: Coloque o vídeo na pasta
```
📂 seu-site/
└── 📂 assets/
    └── 📂 videos/
        └── 🎬 hero.mp4    ← coloque aqui
```

### Passo 3: Configure no código
Abra o `index.html` e procure `EDITAR AQUI: VÍDEO DO HERO`. Edite estas linhas:
```javascript
heroVideo: "assets/videos/hero.mp4",
heroImageFallback: "assets/photos/hero/studio.jpg",  // imagem caso o vídeo não carregue
heroPoster: "assets/photos/hero/poster.jpg",          // imagem enquanto o vídeo carrega
```

### Se não quiser vídeo (só imagem):
Deixe o campo vazio:
```javascript
heroVideo: "",
```
A imagem de fallback será exibida automaticamente.

---

## 📸 Como Trocar/Adicionar Fotos no Portfólio

### Passo 1: Organize suas fotos em pastas
```
📂 assets/
└── 📂 photos/
    ├── 📂 gestantes/
    │   ├── foto1.jpg
    │   └── foto2.jpg
    ├── 📂 batizados/
    ├── 📂 familia/
    ├── 📂 formaturas/
    ├── 📂 shows-eventos/
    └── 📂 miss-concursos/
```

### Passo 2: Adicione no SITE_CONFIG
Procure `EDITAR AQUI: PORTFÓLIO` e adicione linhas assim:
```javascript
{ type: "foto", src: "assets/photos/gestantes/maria.jpg", categoria: "gestantes", titulo: "Ensaio da Maria" },
```

### Tamanhos recomendados para fotos:
- **Portfólio:** 500x667px (3:4), máximo 300KB cada
- **Foto da Bruna (Sobre):** 600x750px
- **Hero fallback:** 1920x1080px
- **Formato:** JPEG ou WebP
- **Otimize em:** [squoosh.app](https://squoosh.app) ou [tinypng.com](https://tinypng.com)

---

## 🎥 Como Adicionar Vídeos no Portfólio

O portfólio suporta **2 tipos de vídeo:**

### Tipo 1: Vídeo Local (MP4)
Coloque o vídeo em `assets/videos/` e uma miniatura em `assets/thumbs/`:
```javascript
{
    type: "video",
    src: "assets/videos/meu-video.mp4",
    thumb: "assets/thumbs/meu-video-thumb.jpg",
    categoria: "gestantes",
    titulo: "Making of - Ensaio Gestante"
},
```

### Tipo 2: Vídeo do YouTube
Pegue o ID do vídeo (a parte depois de `v=` na URL):
- URL: `https://www.youtube.com/watch?v=ABC123`
- ID: `ABC123`

```javascript
{
    type: "youtube",
    videoId: "ABC123",
    thumb: "",              // deixe vazio = YouTube gera automaticamente
    categoria: "batizados",
    titulo: "Highlights - Batizado"
},
```

### Tamanhos recomendados para vídeos:
- **MP4:** máximo 50MB, formato H.264, resolução 1080p
- **Thumbnails:** 500x667px (mesma proporção das fotos)

---

## ✏️ Como Trocar Textos e Links

### WhatsApp
```javascript
whatsapp: "5566999999999",  // código do país + DDD + número
```

### Instagram
```javascript
instagram: "brunabarbosa.photo",  // sem o @
```

### Mensagem automática do WhatsApp
```javascript
whatsappMensagem: "Olá Bruna! Vim pelo seu site...",
```

### Depoimentos
```javascript
depoimentos: [
    { nome: "Nome da Pessoa", texto: "O que ela disse...", estrelas: 5 },
],
```

---

## 🎨 Paleta de Cores (Modern Luxe)

As cores ficam no início do CSS (`:root`):

| Variável | Cor | Uso |
|----------|-----|-----|
| `--bg-primary` | `#FAF8F5` | Fundo principal |
| `--bg-surface` | `#FFFFFF` | Cards |
| `--bg-soft` | `#F0EDE8` | Seções alternadas |
| `--color-primary` | `#A17C4B` | Bronze dourado (botões, destaques) |
| `--color-primary-light` | `#D4B896` | Champagne (hover, detalhes) |
| `--color-primary-dark` | `#7D5E35` | Bronze escuro |
| `--color-accent` | `#C4978A` | Rosa antigo (acento sutil) |
| `--text-primary` | `#1C1917` | Texto principal |
| `--text-secondary` | `#78716C` | Texto secundário |

---

## 🔤 Ícones (Lucide Icons)

O site usa **Lucide Icons** (leve, elegante, profissional).

Para mudar um ícone de serviço, troque o nome no `SITE_CONFIG`:
```javascript
{ id: "gestantes", nome: "Gestantes", icone: "baby", ... },
```

Veja todos os ícones disponíveis em: [lucide.dev/icons](https://lucide.dev/icons)

---

## 📂 Categorias do Portfólio

| Categoria | ID para usar |
|-----------|-------------|
| Gestantes | `gestantes` |
| Batizados | `batizados` |
| Família | `familia` |
| Formaturas | `formaturas` |
| Shows / Eventos | `shows-eventos` |
| Miss / Concursos | `miss-concursos` |

### Para adicionar uma nova categoria:
1. Adicione em `servicos`:
```javascript
{ id: "casamentos", nome: "Casamentos", descricao: "...", icone: "heart" },
```
2. Use `categoria: "casamentos"` nos itens do portfólio.

---

## 📱 Funcionalidades do Site

| Recurso | Descrição |
|---------|-----------|
| 🎬 Hero com vídeo | Vídeo de fundo em loop + fallback imagem |
| 📸 Portfólio com abas | Fotos e Vídeos separados por abas |
| 🏷️ Filtros por categoria | Filtra fotos/vídeos por tipo de ensaio |
| 🔍 Lightbox | Clique na foto = visualização ampliada |
| 🎥 Modal de vídeo | Clique no vídeo = player (MP4 ou YouTube) |
| 📱 Responsivo | Funciona em celular, tablet e PC |
| 💬 WhatsApp | Botão flutuante + links em todo o site |
| ⬆️ Voltar ao topo | Botão aparece ao rolar para baixo |
| 🎨 Animações | Scroll reveal, hover, transições suaves |
| ♿ Acessibilidade | Skip-to-content, foco, aria labels |
| 🔍 SEO | Meta tags, Open Graph, JSON-LD |

---

## 📋 Checklist Antes de Publicar

- [ ] Trocar número do WhatsApp
- [ ] Trocar @ do Instagram
- [ ] Adicionar vídeo do hero (`assets/videos/hero.mp4`)
- [ ] Trocar foto da Bruna (seção Sobre)
- [ ] Adicionar fotos reais no portfólio
- [ ] Adicionar vídeos no portfólio (se tiver)
- [ ] Atualizar depoimentos com clientes reais
- [ ] Testar no celular e no computador
- [ ] Testar links (WhatsApp, Instagram)
- [ ] Testar acessibilidade (navegar com Tab, abrir lightbox com Enter)
- [ ] Publicar no Netlify/Vercel

---

## ✨ Micro-interações e Efeitos (Fase 3 - Polimento)

| Efeito | Onde |
|--------|------|
| Hamburger → X animado | Menu mobile |
| Skeleton shimmer | Galeria enquanto imagem carrega |
| Fade-in suave | Cada imagem ao terminar de carregar |
| Gradient border glow | Cards de serviço no hover |
| Borda luminosa | Cards de depoimento no hover |
| Connector lines | Passos "Como Funciona" (desktop) |
| Float animation | Foto da Bruna na seção Sobre |
| Press effect | Todos os botões ao clicar |
| Bounce animation | Scroll indicator no hero |
| Shimmer circles | Seção CTA de contato |
| Scale hover | Números de estatísticas |

---

## 🛠️ Tecnologias Usadas

| Tecnologia | Para quê |
|-----------|----------|
| HTML5 | Estrutura do site |
| CSS3 | Estilos, gradientes, sombras |
| JavaScript | Interações, galeria, lightbox, modal |
| [Tailwind CSS](https://tailwindcss.com) (CDN) | Classes utilitárias |
| [GSAP](https://greensock.com/gsap) (CDN) | Animações de scroll |
| [Lucide Icons](https://lucide.dev) (CDN) | Ícones profissionais |
| Google Fonts | Tipografia (Playfair Display + Inter) |

---

## 🆘 Problemas Comuns

### "O vídeo do hero não aparece"
- Verifique se o arquivo está em `assets/videos/hero.mp4`
- O formato deve ser MP4 (H.264)
- Se o arquivo for muito grande (>50MB), pode demorar para carregar
- A imagem de fallback aparece automaticamente enquanto isso

### "Os vídeos do portfólio não tocam"
- Vídeos locais: verifique o caminho em `src`
- YouTube: verifique se o `videoId` está correto
- O videoId é só a parte depois de `v=` na URL do YouTube

### "As fotos não aparecem"
- Verifique se o caminho está correto
- Não use espaços ou acentos nos nomes dos arquivos
- O nome é case-sensitive (maiúscula ≠ minúscula)

### "Os ícones não aparecem"
- Precisa de internet (Lucide carrega via CDN)
- Se não carregar, os ícones ficam invisíveis mas o site continua funcionando

### "O WhatsApp não abre"
- Formato correto: `5566999999999` (país + DDD + número)

---

## 📄 Licença

Desenvolvido para **Bruna Barbosa**. Todos os direitos reservados.

---

Feito com 💛 e ☕
